<?php 

class MY_builder extends VP_Control_Field
{
	
}